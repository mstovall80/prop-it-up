import React, { Component } from 'react';
    
    
class PersonCard extends Component {
    constructor(props ){
        super(props);
        this.state= {
            add_age: this.props.age

        }
        
    }
    
    
    render() {
        return (
    <>
            <div>
                <h1> { this.props.firstName } { this.props.lastName }  </h1>
                <h3> age: {this.state.add_age} </h3>
                <h3> hair color: {this.props.hairColor} </h3>
                <button onClick={ ()=> { this.setState({ add_age: this.state.add_age + 1})}}>Birthday Button for zac mac</button>
            </div>
    </>
        )
    }
}
    
export default PersonCard;

                
