import React, { Component } from 'react';



class birthday extends Component {
    constructor(props) {
        super(props);
        const { birthday} = this.props;
        this.state = {
            birthday: birthday,
        };
    }
    
    render() {
        return (
            <fieldset>
                <p>Had a birthday{ this.state.birthday }</p>
                <button>Had a birthday</button>
            </fieldset>
        );
    }
}

export default birthday;
