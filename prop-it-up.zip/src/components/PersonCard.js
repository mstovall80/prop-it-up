import React, { Component } from 'react';
    
    
class PersonCard extends Component {
    constructor(props ){
        super(props);
        const {firstName, lastName, age, hairColor} = this.props;
        this.state= {
            firstName: firstName,
            lastName: lastName,
            age: age,
            hairColor: hairColor,

        }
        
    }
    
    render() {
        return (
    <>
            <div>
                <h1> { this.state.firstName } { this.state.lastName }  </h1>
                <h3> age: {this.state.age} </h3>
                <h3> hair color: {this.state.hairColor} </h3>
            </div>
    </>
        )
    }
}
    
export default PersonCard;
